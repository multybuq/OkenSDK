//
//  OkenSDK.h
//  OkenSDK
//
//  Created by David Dreval on 11.04.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for OkenSDK.
FOUNDATION_EXPORT double OkenSDKVersionNumber;

//! Project version string for OkenSDK.
FOUNDATION_EXPORT const unsigned char OkenSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OkenSDK/PublicHeader.h>


